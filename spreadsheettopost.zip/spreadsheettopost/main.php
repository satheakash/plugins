<?php
//provides access to WP environment
require_once($_SERVER['DOCUMENT_ROOT'] . '/wp-load.php');
/* import
  you get the following information for each file:
  $_FILES['field_name']['name']
  $_FILES['field_name']['size']
  $_FILES['field_name']['type']
  $_FILES['field_name']['tmp_name']
*/
if ($_FILES['upload']['name'])
{
	if (!$_FILES['upload']['error'])
	{
		$new_file_name = strtolower($_FILES['upload']['tmp_name']);
		//can't be larger than 300 KB
		if ($_FILES['upload']['size'] > (300000))
		{
			wp_die('Your file size is to large.');
		}
		else
		{
			//These files need to be included as dependencies when on the front end.
			require_once (ABSPATH . 'wp-admin/includes/image.php');
			require_once (ABSPATH . 'wp-admin/includes/file.php');
			require_once (ABSPATH . 'wp-admin/includes/media.php');

			$file_id = media_handle_upload('upload', 0);

			if (is_wp_error($file_id))
			{
				wp_die('Error loading file!');
			}
			else
			{
				$now = new DateTime();
				$file = fopen(ABSPATH . 'wp-content/uploads/'.date("Y").'/'.$now->format('m').'/' . $_FILES['upload']['name'], 'r');
				if ($file)
				{
					while (($line = fgetcsv($file)) !== false)
					{
						if (isset($line[3]) && $line[3] != '')
						{
							$user_id = username_exists($line[2]);

							if (!$user_id)
							{
								$random_password = wp_generate_password($length = 12, $include_standard_special_chars = false);
								$user_id = wp_create_user($line[2], $random_password, $line[2] . 'test@gmail.com');
								wp_update_user(array(
									'ID' => $user_id,
									'role' => 'Author'
								));
							}

							$id=wp_insert_category(
								array(
									'cat_name'        => $line[0],
									'taxonomy'        => 'types'
								)
							);
							$my_post = array(
								'post_title' => $line[3],
								'post_content' =>$line[4],
								'post_status' => 'publish',
								'post_author' => $user_id,
								'post_type' => 'poadcast' ,
								'post_date' => date("Y-m-d H:i:s", strtotime($line[1])),

							);
							$post_id=wp_insert_post($my_post);
							wp_set_object_terms($post_id, $line[0], 'types' );
						}
					}

					fclose($file);
				}
				else
				{
					die("Unable to open file");
				}
				wp_safe_redirect('?page=upload_csv');
			}
		}
	}
	else
	{
		wp_die('Error: ' . $_FILES['upload']['error']);
	}
}





