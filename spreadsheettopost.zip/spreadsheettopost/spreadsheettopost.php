<?php
/*
   Plugin Name: Spreadsheet To Post 
   Plugin URI: mailto:satheakash68@gmail.com
   Description: Plugin to generate posts from CSV file.
   Version: 1.0
   Author:  akash
   Author URI: mailto:satheakash68@gmail.com
   License: GPL2
   */


function redirect_single_post() {
	if ( is_singular('poadcast') ) {
		global $post;
		$path = $post->post_content;
		header('Location: '.$path);
		exit;
	}
}
add_action( 'template_redirect', 'redirect_single_post' );


function spreadsheet_post_type() {
	register_post_type( 'poadcast',
					   array(
						   'labels' => array(
							   'name' => __( 'Poadcast' ),
							   'singular_name' => __( 'poadcast' ),
						   ),
						   'public' => true,
						   'has_archive' => true,
						   'rewrite' => array('slug' => 'poadcast'),
						   'show_in_rest' => true,
					   )
					  );
}
add_action( 'init', 'spreadsheet_post_type' );


function spreadsheet_taxonomy() {
	$labels = array(
		'name' => _x( 'Types', 'taxonomy general name' ),
		'singular_name' => _x( 'Types', 'taxonomy singular name' ),
		'search_items' =>  __( 'Search Type' ),
		'all_items' => __( 'All Types' ),
		'parent_item' => __( 'Parent Type' ),
		'parent_item_colon' => __( 'Parent Type:' ),
		'edit_item' => __( 'Edit Type' ), 
		'update_item' => __( 'Update Type' ),
		'add_new_item' => __( 'Add New Type' ),
		'new_item_name' => __( 'New Type Name' ),
		'menu_name' => __( 'types' ),
	);    

	// Now register the taxonomy
	register_taxonomy('types',array('poadcast'), array(
		'hierarchical' => true,
		'labels' => $labels,
		'show_ui' => true,
		'show_in_rest' => true,
		'show_admin_column' => true,
		'query_var' => true,
		'rewrite' => array( 'slug' => 'types' ),
	));

}
add_action( 'init', 'spreadsheet_taxonomy', 0 ); 





add_action('admin_menu', 'custom_menu');
function custom_menu() { 

	add_menu_page( 
		'Upload CSV', 
		'Upload CSV', 
		'manage_options', 
		'upload_csv', 
		'page_callback_function',
		'dashicons-media-spreadsheet',
		3);
	add_submenu_page('upload_csv', 'Instructions', 'Instructions', 'manage_options', 'instructions', 'fn_guide');
	add_submenu_page('', 'Submit Post', 'Submit Post', 'manage_options', 'submit-post', 'fn_submit_form');
}

function fn_guide(){
?>
<!doctype html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
	</head>
	<body>
		<div class="section">
			<div class="container">
				<div class="row">
					<div class="col-md-2">
					</div>
					<div class="col-md-8">

						<div class="card pb-0 pt-0 px-0 mw-100">
							<div class="card-header bg-dark text-center">
								<h4 class="mb-0 fw-normal text-white card-title fw-bold">Instructions</h4>
							</div>
							<div class="card-body">
								<div class="accordion" id="accordionPanelsStayOpenExample">
									<div class="accordion-item">
										<h2 class="accordion-header" id="panelsStayOpen-headingOne">
											<button class="accordion-button " type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseOne" aria-expanded="true" aria-controls="panelsStayOpen-collapseOne">
												<h6 class="mb-0 fw-normal text-dark card-title fw-bold">Step 1: Prepare CSV file.</h6>
											</button>
										</h2>
										<div id="panelsStayOpen-collapseOne" class="accordion-collapse collapse show" aria-labelledby="panelsStayOpen-headingOne">
											<div class="accordion-body">
												


												<a class="btn btn-dark btn-sm text-uppercase" href="<?php echo plugin_dir_url( __FILE__ ) . 'images/instructions.png'; ?>" target="_blanck">How to prepare csv file</a>
											</div>
										</div>
									</div>
									<div class="accordion-item">
										<h2 class="accordion-header" id="panelsStayOpen-headingTwo">
											<button class="accordion-button  collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseTwo" aria-expanded="false" aria-controls="panelsStayOpen-collapseTwo">
												<h6 class="mb-0 fw-normal text-dark card-title fw-bold">Step 2: Upload csv file</h6>
											</button>
										</h2>
										<div id="panelsStayOpen-collapseTwo" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingTwo">
											<div class="accordion-body">
												<a class="btn btn-dark btn-sm text-uppercase"  href="?page=upload_csv">Click here</a>
											</div>
										</div>
									</div>

								</div>

							</div>
						</div>



					</div>
					<div class="col-md-2">
					</div>
				</div>

			</div>
		</div>
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
	</body>
</html>
<?php
				   }
function fn_submit_form(){
	require_once('main.php');
}
function page_callback_function() {
?>

<!doctype html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
	</head>
	<body>
		<div class="section">
			<div class="container">
				<div class="row">
					<div class="col-md-3">
					</div>
					<div class="col-md-6">
						<div class="card pb-4 pt-0 px-0 mw-100 border-dark">
							<div class="card-header bg-dark text-center">
								<h4 class="mb-0 fw-normal text-white card-title fw-bold">Choose an csv file to upload.</h4>
							</div>
							<div class="card-body">
								<form id="upload_form" action="?page=submit-post" enctype="multipart/form-data" method="post" target="messages">
									<input name="upload" class="form-control mb-3" id="formFileSm" type="file" accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel" />
									<button type="submit" class="btn btn-dark btn-sm text-uppercase" id="btnSubmit">Upload Stylesheet</button>
									<button type="reset" class="btn btn-secondary btn-sm text-uppercase" id="reset_upload_form">Reset</button>
									<iframe name="messages" id="messages" class="mt-4 w-100"></iframe>
								</form>
							</div>
						</div>
					</div>
					<div class="col-md-3">
					</div>
				</div>
			</div>
		</div>
	</body>
</html>

<?php
}

?>