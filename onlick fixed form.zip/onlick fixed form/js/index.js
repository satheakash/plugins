/*
------------------------------------------------------------
Function to activate form button to open the slider.
------------------------------------------------------------
*/
function open_panel() {
    slideIt();
    var a = document.getElementById("btnOpen");
    a.setAttribute("id", "btnClose");
    a.setAttribute("onclick", "close_panel()");
    }
    /*
    ------------------------------------------------------------
    Function to slide the sidebar form (open form)
    ------------------------------------------------------------
    */
    function slideIt() {
    var slidingDiv = document.getElementById("form-main-div");
    var stopPosition = 0;
    if (parseInt(slidingDiv.style.right) < stopPosition) {
    slidingDiv.style.right = parseInt(slidingDiv.style.right) + 2 + "px";
    setTimeout(slideIt, 1);
    }
    }
    /*
    ------------------------------------------------------------
    Function to activate form button to close the slider.
    ------------------------------------------------------------
    */
    function close_panel() {
    slideIn();
    a = document.getElementById("btnClose");
    a.setAttribute("id", "btnOpen");
    a.setAttribute("onclick", "open_panel()");
    }
    /*
    ------------------------------------------------------------
    Function to slide the sidebar form (slide in form)
    ------------------------------------------------------------
    */
    function slideIn() {
    var slidingDiv = document.getElementById("form-main-div");
    var stopPosition = -509;
    if (parseInt(slidingDiv.style.right) > stopPosition) {
    slidingDiv.style.right = parseInt(slidingDiv.style.right) - 2 + "px";
    setTimeout(slideIn, 1);
    }
    }

// show sticky form button after after body scroll 400 and footer enquiry button also
window.onscroll = function() {scrollFunction()};
function scrollFunction() {
	var bottomEnquiryBtn = document.getElementById("form-main-div");
	
  if (document.body.scrollTop > 400 || document.documentElement.scrollTop > 400) {
    slidingDiv.style.display = "block";
	bottomEnquiryBtn.style.display = "block";

  } else {
    slidingDiv.style.display = "none";
	bottomEnquiryBtn.style.display = "none";

	  
  }
}
    