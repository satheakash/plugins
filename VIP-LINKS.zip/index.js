var btnSave = document.getElementById("btnSave");
var savedList = document.getElementById("savedList");
var listItem = document.getElementById("inputField");
var myLead = [];
var item = "";
btnSave.addEventListener('click', () => {

	if (listItem.value != "") {
		myLead.push(listItem.value);
		localStorage.setItem("myleads", JSON.stringify(myLead));
		console.log(myLead);
		location.reload();


	}


})

myLead = JSON.parse(localStorage.getItem("myleads"));
if (myLead == null) {
	console.log("null")
	myLead = [];
}

if (myLead != "") {
	for (let myleads of myLead) {


		item += `<li class="list-group-item"><a class="text-success text-decoration-none" target="_blanck" href="${myleads}">${myleads}</a></li>`;

	}
	savedList.innerHTML = item;

}


btnDelete.addEventListener('click', () => {
	myLead = [];
	savedList.innerHTML = "";
	localStorage.clear();

})