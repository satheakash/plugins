<?php
/*
   Plugin Name: aswesomeslider
   Plugin URI: mailto:satheakash68@gmail.com
   Description: Plugin to show slider from custom posts.
   Version: 1.0
   Author:  Akash Sathe
   Author URI: mailto:satheakash68@gmail.com
   License: Unknown
   */


   //Register stylesheet
  add_action('wp_enqueue_scripts', 'callback_for_setting_up_scripts');
  function callback_for_setting_up_scripts() {
	  wp_register_style('enque_style', plugins_url('style.css',__FILE__ ));
	  wp_enqueue_style( 'enque_style' );
  }


  //Slider list view shortcode

   function slider_list_view_shortcut() { ?>
<!doctype html>
<html lang="en">
 <head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">


 </head>
 <body>
  <div class="section" id="slider_list_view">
   <div class="container">
    <div class="row">
     <div class="col-md-12">
      <h2 class="text-center testimonial_title">Client Speak</h2>
     </div>
    </div>
    <div class="row"> <?php
					  $args = array(  
						'post_type' => 'poadcast',
						'post_status' => 'publish',
						'posts_per_page' => 3, 
						'orderby' => 'date', 
						'order' => 'DESC', 
					);
					$the_query = new WP_Query( $args ); 
					?> <?php if ( $the_query->have_posts() ) : ?> <?php while ( $the_query->have_posts() ) : $the_query->the_post(); 
					global $post;
					?><div class="col-md-4 text-center">
      <div class="testimonial_inner">
       <div class="entry-content"> <?php

							$_author_image = get_post_meta( $post->ID, "_author_image", true);
							$author_name = get_post_meta( $post->ID, "_author_name", true);
							$author_designation = get_post_meta( $post->ID, "_author_designation", true);
							$author_company = get_post_meta( $post->ID, "_author_company", true);
							$author_testimonial_quote = get_post_meta( $post->ID, "_author_testimonial_quote", true);



					?><div class="quote"><img src="
<?php echo plugin_dir_url( __FILE__ ) . 'images/quote.png'; ?>"></div> <?php if($_author_image!=""){?><img src="
<?php echo $_author_image ?>" class="rounded-circle author_profile" width="150px" height="150px" alt=""> <?php
						}?><h3 class="text-center  mt-2 mb-4 author_name"> <?php echo $author_name?></h3>
        <h4 class="text-center author_designation my-2"> <?php echo $author_designation?></h4>
        <h4 class="text-center author_company my-1"> <?php echo $author_company?></h4>
        <div class="testimonial_quote">
         <p class="text-center testimonial_quote"> <?php echo $author_testimonial_quote?></p>
        </div>
       </div>
      </div>
     </div> <?php endwhile;
					wp_reset_postdata(); ?> <?php else:  ?><p> <?php _e( 'Sorry, no posts matched your criteria.' ); ?></p> <?php endif; ?></div>
   </div>
  </div>
 </body>
</html> <?php
	} 
add_shortcode('testimonial_list_view', 'slider_list_view_shortcut');







//Slider testimonial view shotcode

function testimonial_slider_view_shortcut() {?>
<!DOCTYPE html>
<html lang="en">
 <head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" />
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
 </head>
 <body>
  <div class="section" id="slider_carousel_view">
   <div class="container">
    <div class="row">
     <div class="col-md-12">
      <h2 class="text-center testimonial_title">Client Speak</h2>
     </div>
    </div>
    <div class="row">
     <div class="col-md-12">
      <div id="demo" class="carousel slide" data-ride="carousel">
       <ul class="carousel-indicators mb-0 pb-0">
        <li data-target="#demo" data-slide-to="0" class="active"></li>
        <li data-target="#demo" data-slide-to="1"></li>
        <li data-target="#demo" data-slide-to="2"></li>
       </ul>
       <div class="carousel-inner no-padding my-5">
        <div class="row">
         <div class="col-md-2"></div>
         <div class="col-md-8 slider_column"> <?php
						$carousel_number=0;
					  $args = array(  
						'post_type' => 'poadcast',
						'post_status' => 'publish',
						'posts_per_page' => 3, 
						'orderby' => 'date', 
						'order' => 'DESC', 
					);
					$the_query = new WP_Query( $args ); 
					if ( $the_query->have_posts() ) :
					while ( $the_query->have_posts() ) : $the_query->the_post(); 

					global $post;
					$_author_image = get_post_meta( $post->ID, "_author_image", true);
					$author_name = get_post_meta( $post->ID, "_author_name", true);
					$author_designation = get_post_meta( $post->ID, "_author_designation", true);
					$author_company = get_post_meta( $post->ID, "_author_company", true);
					$author_testimonial_quote = get_post_meta( $post->ID, "_author_testimonial_quote", true);
					
					?> <?php

								if($carousel_number==0){
								?> <div class="carousel-item active text-center"> <?php
								}

								else{
								?> <div class="carousel-item text-center"> <?php
								}


								?>
            <!-- <div class="carousel-item"> -->
            <div class="col-xs-12 col-sm-12 col-md-12">
             <div onclick="abc(this)" class="slider_info">
              <div class="quote">
               <img src="
																<?php echo plugin_dir_url( __FILE__ ) . 'images/quote.png'; ?>">
              </div> <?php if($_author_image!=""){?> <img src="
																<?php echo $_author_image ?>" class="rounded-circle author_profile mb-3" width="150px" height="150px" alt=""> <?php
						}?> <h6 class="text-center  text-white mt-2 mb-4 author_name"> <?php echo $author_name?> </h6>
              <h4 class="text-center author_designation my-2"> <?php echo $author_designation?> </h4>
              <h4 class="text-center author_company"> <?php echo $author_company?> </h4>
              <div class="testimonial_quote">
               <p class="text-center testimonial_quote"> <?php echo $author_testimonial_quote?> </p>
              </div>
             </div>
            </div>
           </div> <?php
											$carousel_number=$carousel_number+1;
 
						
					endwhile;
					wp_reset_postdata(); ?> <?php else:  ?> <p> <?php _e( 'Sorry, no posts matched your criteria.' ); ?> </p> <?php endif; ?> </div>
          <div class="col-md-2"></div>
         </div>
        </div>
       </div>
      </div>
     </div>
    </div>
   </div>
 </body>
</html> <?php
	 } 
 add_shortcode('testimonial_slider_view', 'testimonial_slider_view_shortcut');




//slider meta boxes

function vaze_slider_meta_boxes() {

    $screens = array( 'poadcast' );
    foreach ( $screens as $screen ) {
     
		add_meta_box(
            'author_name',
            __( 'Author Name', 'author  name' ),
            'author_name_meta_box_callback',
            $screen
        );

		add_meta_box(
            'author_designation',
            __( 'Author Designation', 'Author Designation' ),
            'author_designation_meta_box_callback',
            $screen
        );


		add_meta_box(
            'author_company_name',
            __( 'Author company name', 'author company name' ),
            'author_company_meta_box_callback',
            $screen
        );

		add_meta_box(
            'author_testimonial_quote',
            __( 'Author Testimonial Quote', 'author testimonial quote' ),
            'author_testimonial_quote_meta_box_callback',
            $screen
        );

		add_meta_box(
            'author_image',
            __( 'Author Image', 'author image' ),
            'author_image_meta_box_callback',
            $screen
        );

    }
}

add_action( 'add_meta_boxes', 'vaze_slider_meta_boxes' );



function author_name_meta_box_callback( $post ) {

    wp_nonce_field( 'global_notice_nonce', 'global_notice_nonce' );
    $value = get_post_meta( $post->ID, '_author_name', true );
    echo '
			<textarea style="width:100%" id="_author_name" name="_author_name">' . esc_attr( $value ) . '</textarea>';
}

function author_designation_meta_box_callback( $post ) {

    wp_nonce_field( 'global_notice_nonce', 'global_notice_nonce' );
    $value = get_post_meta( $post->ID, '_author_designation', true );
    echo '
			<textarea style="width:100%" id="_author_designation" name="_author_designation">' . esc_attr( $value ) . '</textarea>';
}


function author_company_meta_box_callback( $post ) {

    wp_nonce_field( 'global_notice_nonce', 'global_notice_nonce' );
    $value = get_post_meta( $post->ID, '_author_company', true );
    echo '
			<textarea style="width:100%" id="_author_company" name="_author_company">' . esc_attr( $value ) . '</textarea>';
}

function author_testimonial_quote_meta_box_callback( $post ) {

    wp_nonce_field( 'global_notice_nonce', 'global_notice_nonce' );
    $value = get_post_meta( $post->ID, '_author_testimonial_quote', true );
    echo '
			<textarea style="width:100%" id="_author_testimonial_quote" name="_author_testimonial_quote">' . esc_attr( $value ) . '</textarea>';
}


function author_image_meta_box_callback( $post ) {

    wp_nonce_field( 'global_notice_nonce', 'global_notice_nonce' );
    $value = get_post_meta( $post->ID, '_author_image', true );
    echo '
			<textarea style="width:100%" placeholder="Url of the image" id="_author_image" name="_author_image">' . esc_attr( $value ) . '</textarea>';
}


//Save meta boxes

function save_global_notice_meta_box_data( $post_id ) {



	$author_company = sanitize_text_field( $_POST['_author_company'] );
    update_post_meta( $post_id, '_author_company', $author_company );

	$author_name = sanitize_text_field( $_POST['_author_name'] );
    update_post_meta( $post_id, '_author_name', $author_name );

	$author_designation = sanitize_text_field( $_POST['_author_designation'] );
    update_post_meta( $post_id, '_author_designation', $author_designation );

	$author_testimonial_quote = sanitize_text_field( $_POST['_author_testimonial_quote'] );
    update_post_meta( $post_id, '_author_testimonial_quote', $author_testimonial_quote );

	$author_image = sanitize_text_field( $_POST['_author_image'] );
    update_post_meta( $post_id, '_author_image', $author_image );
}

add_action( 'save_post', 'save_global_notice_meta_box_data' );



//Generate custom post types

function vaze_post_type() {
	register_post_type( 'poadcast',
					   array(
						   'labels' => array(
							   'name' => __( 'awesome slider' ),
							   'singular_name' => __( 'poadcast' ),
						   ),
						   'public' => true,
						   'has_archive' => true,
						   'rewrite' => array('slug' => 'poadcast'),
						   'show_in_rest' => true,
					   )
					  );
}
add_action( 'init', 'vaze_post_type' );


function vaze_texonomy() {
	$labels = array(
		'name' => _x( 'Types', 'taxonomy general name' ),
		'singular_name' => _x( 'Types', 'taxonomy singular name' ),
		'search_items' =>  __( 'Search Type' ),
		'all_items' => __( 'All Types' ),
		'parent_item' => __( 'Parent Type' ),
		'parent_item_colon' => __( 'Parent Type:' ),
		'edit_item' => __( 'Edit Type' ), 
		'update_item' => __( 'Update Type' ),
		'add_new_item' => __( 'Add New Type' ),
		'new_item_name' => __( 'New Type Name' ),
		'menu_name' => __( 'types' ),
	);    

	// Now register the taxonomy
	register_taxonomy('types',array('poadcast'), array(
		'hierarchical' => true,
		'labels' => $labels,
		'show_ui' => true,
		'show_in_rest' => true,
		'show_admin_column' => true,
		'query_var' => true,
		'rewrite' => array( 'slug' => 'types' ),
	));

}
add_action( 'init', 'vaze_texonomy', 0 ); 





add_action('admin_menu', 'custom_menu');
function custom_menu() { 

	add_menu_page( 
		'Awesome Shortcodes', 
		'Awesome Shortcodes', 
		'manage_options', 
		'shortcodes', 
		'page_callback_function',
		'dashicons-media-spreadsheet',
		3);
}

function page_callback_function() {
?>
<!doctype html>
<html lang="en">
 <head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
 </head>
 <body>
  <div class="section">
   <div class="container">
    <div class="row">
     <div class="col-md-3"></div>
     <div class="col-md-6">
      <div class="card pb-4 pt-0 px-0 mw-100 border-dark">
       <div class="card-header bg-dark text-center">
        <h4 class="mb-0 fw-normal text-white card-title fw-bold">Shortcodes</h4>
       </div>
       <div class="card-body">
        <h2 class="text-center text-primary">[testimonial_list_view]
</h2>
        <h2 class="text-center text-primary">[testimonial_slider_view]</h2>
        <p class="text-success">Shortcode work fine with the page builders like <strong>Elementor</strong>,<strong>Divi</strong> and <strong>Visual Composer</strong></p>
        <p class="text-success">Create your first slider by clicking <strong>awesome slider </strong>menu.</p>

       </div>
      </div>
     </div>
     <div class="col-md-3"></div>
    </div>
   </div>
  </div>
 </body>
</html> <?php
}

?>